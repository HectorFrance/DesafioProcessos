package desafio.processos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcessosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcessosApplication.class, args);
	}

}
